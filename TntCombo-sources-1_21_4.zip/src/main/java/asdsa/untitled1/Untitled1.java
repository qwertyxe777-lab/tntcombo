package asdsa.untitled1;

import net.fabricmc.api.ModInitializer;

public class Untitled1 implements ModInitializer {
    @Override
    public void onInitialize() {
        // Вся логика мода — на клиенте.
    }
}
