package asdsa.untitled1.client;

import net.minecraft.block.Blocks;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.entity.player.PlayerInventory;
import net.minecraft.item.Item;
import net.minecraft.item.Items;
import net.minecraft.network.packet.c2s.play.UpdateSelectedSlotC2SPacket;
import net.minecraft.screen.Generic3x3ContainerScreenHandler;
import net.minecraft.screen.slot.Slot;
import net.minecraft.screen.slot.SlotActionType;
import net.minecraft.text.Text;
import net.minecraft.util.Hand;
import net.minecraft.util.hit.BlockHitResult;
import net.minecraft.util.hit.HitResult;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Box;
import net.minecraft.util.math.Direction;
import net.minecraft.util.math.Vec3d;

/**
 * Если в хотбаре есть редстоун-блок, раздатчик и динамит — по нажатию клавиши:
 * 1) ставит редстоун-блок туда, куда смотрит игрок;
 * 2) ставит рядом с ним раздатчик;
 * 3) открывает раздатчик и кладёт в него динамит из хотбара.
 *
 * Порядок выбран так (редстоун -> раздатчик -> динамит), чтобы раздатчик
 * НЕ выстрелил сразу: загрузка предметов не даёт импульс.
 */
public class TntCombo {
    private enum Stage { IDLE, WAIT_REDSTONE, WAIT_DISPENSER, WAIT_GUI }

    private static final int TIMEOUT_TICKS = 40;

    private static final Direction[] DISPENSER_SIDES = {
            Direction.UP, Direction.NORTH, Direction.SOUTH, Direction.EAST, Direction.WEST, Direction.DOWN
    };

    private Stage stage = Stage.IDLE;
    private int timeout;
    private int previousSlot;
    private int redstoneSlot, dispenserSlot;
    private BlockPos redstonePos, dispenserPos;
    private Direction dispenserSide;

    public void start(MinecraftClient client) {
        ClientPlayerEntity player = client.player;
        if (player == null || client.world == null || client.interactionManager == null) return;
        if (stage != Stage.IDLE || client.currentScreen != null) return;

        if (player.isSneaking()) {
            msg(player, "message.untitled1.no_sneak");
            return;
        }

        redstoneSlot = findInHotbar(player, Items.REDSTONE_BLOCK);
        dispenserSlot = findInHotbar(player, Items.DISPENSER);
        int tntSlot = findInHotbar(player, Items.TNT);
        if (redstoneSlot < 0 || dispenserSlot < 0 || tntSlot < 0) {
            msg(player, "message.untitled1.need_items");
            return;
        }

        if (!(client.crosshairTarget instanceof BlockHitResult hit) || hit.getType() != HitResult.Type.BLOCK) {
            msg(player, "message.untitled1.need_block");
            return;
        }

        redstonePos = hit.getBlockPos().offset(hit.getSide());
        if (!canPlaceAt(client, redstonePos)) {
            msg(player, "message.untitled1.no_space");
            return;
        }

        // Сторона редстоун-блока, к которой прикрепим раздатчик.
        dispenserSide = null;
        for (Direction side : DISPENSER_SIDES) {
            if (side == hit.getSide().getOpposite()) continue; // там опорный блок
            if (canPlaceAt(client, redstonePos.offset(side))) {
                dispenserSide = side;
                break;
            }
        }
        if (dispenserSide == null) {
            msg(player, "message.untitled1.no_space");
            return;
        }
        dispenserPos = redstonePos.offset(dispenserSide);

        previousSlot = player.getInventory().selectedSlot;
        selectSlot(player, redstoneSlot);
        interact(client, hit);

        stage = Stage.WAIT_REDSTONE;
        timeout = TIMEOUT_TICKS;
    }

    public void tick(MinecraftClient client) {
        if (stage == Stage.IDLE) return;
        ClientPlayerEntity player = client.player;
        if (player == null || client.world == null || client.interactionManager == null) {
            stage = Stage.IDLE;
            return;
        }

        if (--timeout <= 0) {
            abort(client, player);
            return;
        }

        switch (stage) {
            case WAIT_REDSTONE -> {
                if (client.world.getBlockState(redstonePos).isOf(Blocks.REDSTONE_BLOCK)) {
                    selectSlot(player, dispenserSlot);
                    // Кликаем по грани редстоун-блока, раздатчик встанет в dispenserPos.
                    Vec3d face = Vec3d.ofCenter(redstonePos).add(
                            dispenserSide.getOffsetX() * 0.5,
                            dispenserSide.getOffsetY() * 0.5,
                            dispenserSide.getOffsetZ() * 0.5);
                    interact(client, new BlockHitResult(face, dispenserSide, redstonePos, false));
                    stage = Stage.WAIT_DISPENSER;
                    timeout = TIMEOUT_TICKS;
                }
            }
            case WAIT_DISPENSER -> {
                if (client.world.getBlockState(dispenserPos).isOf(Blocks.DISPENSER)) {
                    // ПКМ по раздатчику открывает его интерфейс.
                    Vec3d top = Vec3d.ofCenter(dispenserPos).add(0, 0.5, 0);
                    interact(client, new BlockHitResult(top, Direction.UP, dispenserPos, false));
                    stage = Stage.WAIT_GUI;
                    timeout = TIMEOUT_TICKS;
                }
            }
            case WAIT_GUI -> {
                if (player.currentScreenHandler instanceof Generic3x3ContainerScreenHandler handler
                        && handler != player.playerScreenHandler) {
                    for (Slot slot : handler.slots) {
                        if (slot.inventory instanceof PlayerInventory
                                && slot.getIndex() < 9
                                && slot.getStack().isOf(Items.TNT)) {
                            // Shift-клик: переносит весь стак динамита в раздатчик.
                            client.interactionManager.clickSlot(
                                    handler.syncId, slot.id, 0, SlotActionType.QUICK_MOVE, player);
                            break;
                        }
                    }
                    player.closeHandledScreen();
                    finish(player);
                    msg(player, "message.untitled1.done");
                }
            }
            default -> { }
        }
    }

    // ---------------------------------------------------------------- helpers

    private void abort(MinecraftClient client, ClientPlayerEntity player) {
        if (player.currentScreenHandler != player.playerScreenHandler) {
            player.closeHandledScreen();
        }
        finish(player);
        msg(player, "message.untitled1.failed");
    }

    private void finish(ClientPlayerEntity player) {
        selectSlot(player, previousSlot);
        stage = Stage.IDLE;
    }

    private static int findInHotbar(ClientPlayerEntity player, Item item) {
        for (int i = 0; i < 9; i++) {
            if (player.getInventory().getStack(i).isOf(item)) return i;
        }
        return -1;
    }

    private static boolean canPlaceAt(MinecraftClient client, BlockPos pos) {
        return client.world.getBlockState(pos).isReplaceable()
                && !client.player.getBoundingBox().intersects(new Box(pos));
    }

    private static void selectSlot(ClientPlayerEntity player, int slot) {
        player.getInventory().selectedSlot = slot;
        player.networkHandler.sendPacket(new UpdateSelectedSlotC2SPacket(slot));
    }

    private static void interact(MinecraftClient client, BlockHitResult hit) {
        client.interactionManager.interactBlock(client.player, Hand.MAIN_HAND, hit);
        client.player.swingHand(Hand.MAIN_HAND);
    }

    private static void msg(ClientPlayerEntity player, String key) {
        player.sendMessage(Text.translatable(key), true);
    }
}
