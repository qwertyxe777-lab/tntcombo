package asdsa.untitled1.client;

import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.keybinding.v1.KeyBindingHelper;
import net.minecraft.client.option.KeyBinding;
import net.minecraft.client.util.InputUtil;
import org.lwjgl.glfw.GLFW;

@Environment(EnvType.CLIENT)
public class Untitled1Client implements ClientModInitializer {
    private static KeyBinding TRIGGER_KEY;
    private final TntCombo combo = new TntCombo();

    @Override
    public void onInitializeClient() {
        TRIGGER_KEY = KeyBindingHelper.registerKeyBinding(new KeyBinding(
                "key.untitled1.tnt_combo",
                InputUtil.Type.KEYSYM,
                GLFW.GLFW_KEY_G,
                "key.category.untitled1.tnt"
        ));

        ClientTickEvents.END_CLIENT_TICK.register(client -> {
            while (TRIGGER_KEY.wasPressed()) {
                combo.start(client);
            }
            combo.tick(client);
        });
    }
}
